package components

import (
	"github.com/erroneousboat/termui"
)

const (
	CommandMode = "NORMAL"
	InsertMode  = "INSERT"
	SearchMode  = "SEARCH"
)

// Mode is the definition of Mode component
type Mode struct {
	Par *termui.Par
}

// CreateMode is the constructor of the Mode struct
func CreateModeComponent() *Mode {
	mode := &Mode{
		Par: termui.NewPar(CommandMode),
	}

	mode.Par.Height = 3
	mode.SetCommandMode()

	return mode
}

// Buffer implements interface termui.Bufferer
func (m *Mode) Buffer() termui.Buffer {
	buf := m.Par.Buffer()

	// Center text
	space := m.Par.InnerWidth()
	word := len(m.Par.Text)

	midSpace := space / 2
	midWord := word / 2

	start := midSpace - midWord

	cells := termui.DefaultTxBuilder.Build(
		m.Par.Text, m.Par.TextFgColor, m.Par.TextBgColor)

	i, j := 0, 0
	x := m.Par.InnerBounds().Min.X
	for x < m.Par.InnerBounds().Max.X {
		if i < start {
			buf.Set(
				x, m.Par.InnerY(),
				termui.Cell{
					Ch: ' ',
					Fg: m.Par.TextFgColor,
					Bg: m.Par.TextBgColor,
				},
			)
			x++
			i++
		} else {
			if j < len(cells) {
				buf.Set(x, m.Par.InnerY(), cells[j])
				i++
				j++
			}
			x++
		}
	}

	return buf
}

// GetHeight implements interface termui.GridBufferer
func (m *Mode) GetHeight() int {
	return m.Par.Block.GetHeight()
}

// SetWidth implements interface termui.GridBufferer
func (m *Mode) SetWidth(w int) {
	m.Par.SetWidth(w)
}

// SetX implements interface termui.GridBufferer
func (m *Mode) SetX(x int) {
	m.Par.SetX(x)
}

// SetY implements interface termui.GridBufferer
func (m *Mode) SetY(y int) {
	m.Par.SetY(y)
}

func (m *Mode) SetInsertMode() {
	m.Par.Text = InsertMode
	termui.Render(m)
}

func (m *Mode) SetCommandMode() {
	m.Par.Text = CommandMode
	termui.Render(m)
}

func (m *Mode) SetSearchMode() {
	m.Par.Text = SearchMode
	termui.Render(m)
}
