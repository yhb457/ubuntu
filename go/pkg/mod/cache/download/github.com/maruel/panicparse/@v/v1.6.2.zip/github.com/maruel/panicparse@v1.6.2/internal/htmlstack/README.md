# Templates

Contains an HTML template and an icon.

emoji_u1f4a3.png is the bomb emoji U+1F4A3 in Noto Emoji as a PNG.
emoji_u1f4a3_64.gif is the product of reducing the image to 64x64 and exporting
as GIF.

## Source

It can be found online at
https://github.com/googlefonts/noto-emoji/blob/master/png/128/emoji_u1f4a3.png

## License

Found in [OFL.txt](OFL.txt). An online copy can be retrieved at
http://scripts.sil.org/cms/scripts/page.php?site_id=nrsi&id=OFL
